<div class="jumbotron">
	<h1 class="display-3 text-center">Code Is Better Than Chocolate!</h1>
	<p class="lead text-center">We at Algo Stacks provide the best solutions tailored to your needs using cutting edge technologies.</p>
	<hr class="my-4">
	<p class="text-center">A team of highly trained professionals is always ready to deliver the customized products and services following latest trends.</p>
</div>