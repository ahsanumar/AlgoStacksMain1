<?php

$pageName = "Home";

require_once "head.php";

require_once "nav.php";

require_once "mainJmb.php";

require_once "testemonial.php";

require_once "footer.php";

?>